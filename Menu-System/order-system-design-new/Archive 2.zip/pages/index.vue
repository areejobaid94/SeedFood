<template>
  <div class="w-100">
    <div class="col-lg-12 h-100 container">
      <div class="row h-100">
        <div class="col-lg-12 px-0 pr-lg-2 mb-2 mb-lg-0">
          <div class="card border-light bg-white card proviewcard shadow-sm h-100">
            <div class="card-header p-0">
              <div class="row pl-2 pr-2">
                <div class="col-12 font-14">
                  <div class="input-group">
                    <input
                      v-model="search"
                      type="text"
                      class="form-control border-0 border-bottom"
                      name="search"
                      placeholder="Search..."
                    >
                    <span class="input-group-btn pt-2 mr-3">
                      <i class="fa fa-search" />
                    </span>
                    <div class="input-group-btn search-panel pt-1 font-14">
                      <b-dropdown
                        size="sm"
                        block
                        variant="link"
                        toggle-class="text-decoration-none"
                        no-caret
                        right
                      >
                        <template #button-content>
                          <i class="fa fa-th-list" /> <span class="">Categories</span>
                        </template>
                        <b-dropdown-item
                          v-for="category in categories"
                          :key="category.id"
                          :href="'#category'+category.id"
                        >
                          {{ category.name }}
                        </b-dropdown-item>
                      </b-dropdown>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="content-items h-100vh">
              <div class="card-body">
                <div
                  v-for="(category,i) of items"
                  :id="'category'+category.categoryId"
                  :key="category.id"
                  class="col-md-12"
                >
                  <div
                    class="col-md-12"
                    :style="{display:category.listItemInCategories.length>0?'block':'none'}"
                    :class="{'pt-3':i===0}"
                  >
                    <h5
                      v-if="search.length===0"
                      class="menu-title"
                    >
                      {{ category.categoryName }}
                    </h5>
                  </div>
                  <div
                    v-for="item of filteredList(category.listItemInCategories)"
                    :key="item.id"
                    class="col-lg-12 p-3 cardlist"
                  >
                    <div class="col-lg-12">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="row">
                            <div class="col-3 col-lg-3 col-xl-3">
                              <div class="row">
                                <a
                                  class="w-100"
                                  @click="openImage(item.imageUri)"
                                >
                                  <div
                                    class="item-image"
                                    :style="{backgroundImage:`url(${item.imageUri&&item.imageUri.length>1?item.imageUri:require('assets/empty-item.jpeg')})`}"
                                  />

                                </a>
                              </div>
                            </div>

                            <div class="col-6 col-lg-6 col-xl-6 text-left">
                              <div class="d-block mb-1">
                                <a class="cartproname">{{ item.itemName }}</a>
                              </div>
                              <div class="seller d-block">
                                <span>{{ item.itemDescription }}  </span>
                              </div>
                              <div class="cartviewprice d-block">
                                <span class="amt">    {{
                                  item.price.toLocaleString({
                                    style: 'currency',
                                    currency: 'JOD'
                                  })
                                }} JOD</span>
                              </div>
                            </div>

                            <div class="col-3 col-lg-3 col-xl-3 p-0 qty">
                              <button
                                v-if="!isItemAdded(item)"
                                type="button"
                                class="btn btn-light btn-sm w-100 border"
                                data-field="quantity"
                                @click="addItem(item)"
                              >
                                Add
                              </button>

                              <div v-if="isItemAdded(item)" class="input-group">
                                <div class="input-group-prepend" @click="removeItem(item)">
                                  <button type="button" class="btn btn-sm btn-qty">
                                    <i class="fa fa-minus" />
                                  </button>
                                </div>
                                <input
                                  id=""
                                  type="text"
                                  class="form-control item-qty form-control-sm text-center"
                                  aria-describedby=""
                                  :value="selectedItems[getItem(item)].count"
                                  disabled
                                >
                                <div class="input-group-append" @click="addItem(item)">
                                  <button type="button" class="btn btn-sm btn-qty">
                                    <i class="fa fa-plus" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div style="margin-left: 30px;">
                            <div
                              v-for="itemAddOn in item.itemAdditionDtos"
                              :key="itemAddOn.id"
                              class="row "
                              style="margin-top: 22px;"
                            >
                              <div v-if="isItemAdded(item)" class="row " style="width: 500px;">
                                <div style="margin-right: 31px; width: 70px;">
                                  <a class="cartproname">{{ itemAddOn.name }}</a>
                                </div>

                                <div style="margin-right: 31px; width: 70px;">
                                  <span class="amt">    {{
                                    itemAddOn.price.toLocaleString({
                                      style: 'currency',
                                      currency: 'JOD'
                                    })
                                  }} JOD</span>
                                </div>

                                <div class="col-3 col-lg-3 col-xl-3 p-0 qty">
                                  <button
                                    v-if="!isItemAddOnAdded(itemAddOn)"
                                    type="button"
                                    class="btn btn-light btn-sm w-100 border"
                                    data-field="quantity"
                                    @click="addOnItem(item,itemAddOn)"
                                  >
                                    Add
                                  </button>

                                  <div v-if="isItemAddOnAdded(itemAddOn)" class="input-group">
                                    <div class="input-group-prepend" @click="removeItemAddOn(item,itemAddOn)">
                                      <button type="button" class="btn btn-sm btn-qty">
                                        <i class="fa fa-minus" />
                                      </button>
                                    </div>
                                    <input
                                      id=""
                                      type="text"
                                      class="form-control item-qty form-control-sm text-center"
                                      aria-describedby=""
                                      :value="selectedItemsAddOn[getItemAddOn(itemAddOn)].count"
                                      disabled
                                    >
                                    <div class="input-group-append" @click="addOnItem(item,itemAddOn)">
                                      <button type="button" class="btn btn-sm btn-qty">
                                        <i class="fa fa-plus" />
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div
              v-if="selectedItems.length>0"
              class="card-footer fixed w-full border-light cart-panel-foo-fix"
            >
              <a href="" class="btn btn-add-con"> {{
                total.toLocaleString({
                  style: 'currency',
                  currency: 'JOD'
                })
              }} JOD</a>
              <input
                type="button"
                :disabled="loadingSendOrder"
                class="btn btn-cust"
                value="Send Order"
                @click="sendOrder()"
              >
            </div>
          </div>
        </div>
      </div>
    </div>
    <CoolLightBox
      :items="selectedImage"
      :index="imageIndex"
      @close="imageIndex = null"
    />
  </div>
</template>

<script>

import axios from 'axios'
import CoolLightBox from 'vue-cool-lightbox'
import 'vue-cool-lightbox/dist/vue-cool-lightbox.min.css'

export default {
  components: {
    CoolLightBox
  },
  data () {
    return {
      items: [],
      selectedItems: [],
      selectedItemsAddOn: [],
      search: '',
      tenantID: '',
      contactId: '',
      total: 0,
      selectedImage: [],
      imageIndex: null,
      categories: [],
      loadingSendOrder: false

    }
  },
  mounted () {
    // const isOpen = this.$route.query.isOpen
    // if (!isOpen) {
    //   window.open(window.location + '&isOpen=true', '_self')
    // }
    this.tenantID = this.$route.query.TenantID
    this.contactId = this.$route.query.ContactId

    this.getAllCategory()
    axios.get(`${this.$axios.defaults.baseURL}/api/services/app/Menus/GetCategorysInItemWithTenantId?TenantID=${this.tenantID}&ContactId=${this.contactId}`, {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    }).then((res) => {
      this.items = res.data.result
      this.$forceUpdate()
    })
  },
  methods: {
    addItem (selectedItem) {
      const itemIndex = this.selectedItems.findIndex(item => item.id === selectedItem.id)

      if (itemIndex !== -1) {
        this.selectedItems[itemIndex].count += 1
      } else {
        selectedItem.count = 1
        this.selectedItems.push(selectedItem)
      }
      this.total = this.getTotal()
      this.$forceUpdate()
    },

    addOnItem (selectedItem, selectedItemAddOn) {
      const itemIndex = this.selectedItemsAddOn.findIndex(item => item.id === selectedItemAddOn.id)

      if (itemIndex !== -1) {
        this.selectedItemsAddOn[itemIndex].count += 1
      } else {
        selectedItemAddOn.count = 1
        this.selectedItemsAddOn.push(selectedItemAddOn)
      }
      this.total = this.getTotal()
      this.$forceUpdate()
    },
    removeItem (selectedItem) {
      const itemIndex = this.selectedItems.findIndex(item => item.id === selectedItem.id)
      if (itemIndex !== -1) {
        if (this.selectedItems[itemIndex].count - 1 === 0) {
          this.selectedItems.splice(itemIndex, 1)
        } else {
          this.selectedItems[itemIndex].count -= 1
        }
      }
      this.total = this.getTotal()

      this.$forceUpdate()
    },

    removeItemAddOn (selectedItem, selectedItemAddOn) {
      const itemIndex = this.selectedItemsAddOn.findIndex(item => item.id === selectedItemAddOn.id)
      if (itemIndex !== -1) {
        if (this.selectedItemsAddOn[itemIndex].count - 1 === 0) {
          this.selectedItemsAddOn.splice(itemIndex, 1)
        } else {
          this.selectedItemsAddOn[itemIndex].count -= 1
        }
      }
      this.total = this.getTotal()

      this.$forceUpdate()
    },

    isItemAdded (selectedItem) {
      const itemIndex = this.selectedItems.findIndex(item => item.id === selectedItem.id)
      if (itemIndex !== -1) {
        return true
      }

      return false
    },

    isItemAddOnAdded (selectedItem) {
      const itemIndex = this.selectedItemsAddOn.findIndex(item => item.id === selectedItem.id)
      if (itemIndex !== -1) {
        return true
      }

      return false
    },
    getItem (item) {
      const itemIndex = this.selectedItems.findIndex(i => i.id === item.id)
      if (itemIndex !== -1) {
        return itemIndex
      }
      return null
    },

    getItemAddOn (item) {
      const itemIndex = this.selectedItemsAddOn.findIndex(i => i.id === item.id)
      if (itemIndex !== -1) {
        return itemIndex
      }
      return null
    },
    getTotal () {
      let total = 0
      this.selectedItems.forEach((item) => {
        total += (item.count * item.price)
      })

      this.selectedItemsAddOn.forEach((item) => {
        total += (item.count * item.price)
      })

      return total
    },

    getTotalAddOn () {
      let total = 0
      this.selectedItemsAddOn.forEach((item) => {
        total += (item.count * item.price)
      })
      return total
    },

    sendOrder () {
      // window.close()
      if (this.selectedItems.length > 0) {
        const cartItem = []
        const cartItemExt = []
        let total = 0
        let totalExt = 0
        this.loadingSendOrder = true

        this.selectedItemsAddOn.forEach((item2) => {
          cartItemExt.push({
            quantity: item2.count,
            unitPrice: item2.price,
            total: item2.count * item2.price,
            name: item2.name,
            itemId: item2.itemId
          })

          totalExt += (item2.count * item2.price)
        })

        this.selectedItems.forEach((item) => {
          cartItem.push({
            quantity: item.count,
            unitPrice: item.price,
            total: item.count * item.price,
            discount: 0,
            itemId: item.id,
            createExtraOrderDetailsModels: cartItemExt
          })

          total += (item.count * item.price)
        })

        total += totalExt

        const obj = {
          tenantId: this.tenantID,
          customerId: this.contactId,
          createOrderDetailsModels: cartItem,
          total,
          event: 'botjoin'
        }
        axios.post(`${this.$axios.defaults.baseURL}/api/services/app/Orders/CreateOrder`, obj, {
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        }).then((res) => {
          this.$swal.fire(
            'لاكمال الطلب  <br>',
            'يرجى العودة الى واتسب ',
            'success'
          ).then(function () {
            window.location = 'https://wa.me/'
          })
          this.loadingSendOrder = false
          this.selectedItems = []
        })
      }
    },
    filteredList (item) {
      if (this.search.length > 0) {
        return item.filter((post) => {
          return post.itemName.toLowerCase().includes(this.search.toLowerCase())
        })
      }
      return item
    },
    openImage (image) {
      this.selectedImage = [image]
      this.imageIndex = 0
    },
    getAllCategory () {
      axios.get(`${this.$axios.defaults.baseURL}/api/services/app/ItemCategory/GetAllWithTenantID?TenantID=${this.tenantID}`, {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      }).then((res) => {
        this.categories = res.data.result
        this.$forceUpdate()
      })
    }
  }
}
</script>
<style scoped>

</style>
