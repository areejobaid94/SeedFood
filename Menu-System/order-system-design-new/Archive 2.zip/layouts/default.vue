<template>
  <div class="d-flex flex-row">
    <Nuxt/>
  </div>
</template>
